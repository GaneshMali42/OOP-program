#include<stdio.h>
#include<iostream>
using namespace std;
int main()
{
	float a,b,c;
	cout<<"\nEnter the A:";
	cin>>a;
	cout<<"\nEnter the B:";
	cin>>b;
	cout<<"\nEnter the C:";
	cin>>c;
	
	if(a>b)
	{
		if(a>c)
		{
			cout<<"\n"<<a<<"is larger";
		}
		else
		{
			cout<<"\n"<<c<<"is larger";
		}
	}
	else
	{
		if(b>c)
		{
			cout<<"\n"<<b<<"is larger";
		}
		else{
			cout<<"\n"<<c<<"is larger";
		}
	}
	
}
