#include<stdio.h>
#include<iostream>
using namespace std;
int main()
{
	float Add,Sub,Mul,a,b;
	double Div;
	cout<<"\n Enter the two Numbers";
	cin>>a>>b;
	Add=a+b;
	cout<<"\n addition"<<Add;
	Sub=a-b;
	cout<<"\n Subtraction:"<<Sub;
	Div=a/b;
	cout<<"\n Division:"<<Div;
	Mul=a*b;
	cout<<"\n Multiple:"<<Mul;
	int Mod=(int)a%(int)b;
	cout<<"\n Module:"<<Mod;
}
