#include<stdio.h>
#include<iostream>
using namespace std;
int main()
{
	float num;
	cout<<"\n Enter the number";
	cin>>num;
	for(int i=1;i<11;i++)
	{
		cout<<"\n"<<num*i;
	}
}
